%% ����˵��
% ��һ�У�������
% �ڶ��У������
% �����У���Ӧ����ɼӹ��Ļ�����
% �����У���Ӧ����ɼӹ��Ļ�����
% �����У���Ӧ�����ļӹ�ʱ��
% �����У���Ӧ�����ĵ�λ��̼
%% ������������� �������� ����������Ϣ ������ ������
%% �����
% ������Ϣjob_set��������λ�á��׶Ρ�������
% ��������Ϣmanufacturer_set��λ�á��ӹ�ʱ�䡢��λ�ӹ��ɱ���
% ����������Ϣservicer_set�������ٶȡ���λ�ɱ��������������������ء���λ����ɱ���
% V_p:ÿ�������ڸ��������µ�����Ч�� % V_de:ÿ�������ڸ��������µĶ�Ч�� % due_multi_p:ÿ��������Ӧÿ�������Ľ���ʱ��
% hv ����ֵ
clc
clear
dbstop if error
due_multi_p=[];
V_d=[];
V_p=[];
V_de=[];
w=0;
job_numset=[20 40 60 80 100]; %������
stage_numset=[2,4,6];%�׶���
tran_num=3;
for ii=1:length(stage_numset)
    for y=1:length(job_numset)

        %% ����������Ϣ
            for group=1:5
                job_num=job_numset(y);
                stage_num=stage_numset(ii);
                job_set(1:job_num)=struct('job_rank',[],'stage',[],'avai_mach_num',[],'avai_mach',[],'pro_time',[],'location',[],'due_multi_p',[],'V_p',[],'V_de',[],'hv',[]);
                avai_mach=[];
                mach_set=[];
                avai_mach_num=[];
                avai_worker=[];
                worker_set=[];
                avai_worker_num=[];
                for j=1:stage_num
                    avai_mach_num(j)=round(2+3*rand);
                    avai_worker_num(j)=round(2+rand);
                    if j==1
                        avai_mach(j,:)=1:avai_mach_num(1,j);
                        avai_worker(j,:)=1:avai_worker_num(1,j);
                    else
                        mach_set=avai_mach(j-1,:);
                        for uu=1:length(mach_set)
                            if mach_set(uu)==0
                                mach_set(uu:end)=[];
                                break;
                            end
                        end
                        worker_set=avai_worker(j-1,:);
                        for ww=1:length(worker_set)
                            if worker_set(ww)==0
                                worker_set(ww:end)=[];
                                break;
                            end
                        end
                        avai_mach(j,1:avai_mach_num(1,j))=(1+mach_set(end)):(mach_set(end)+avai_mach_num(1,j));
                        avai_worker(j,1:avai_worker_num(1,j))=(1+worker_set(end)):(worker_set(end)+avai_worker_num(1,j));
                    end
                end
                manuf_location=[round(rand(1)*500);round(rand(1)*500)];
                tran_set=struct('speed',[]);
                tran_set.speed=randi([10,20]);      %�����ٶ�
                for i=1:job_num
                    job_set(i).job_rank=i;
                    job_set(i).stage=stage_numset(ii);
                    job_set(i).location=[round(rand(1)*500);round(rand(1)*500)];
                    job_set(i).avai_mach_num=avai_mach_num;
                    job_set(i).avai_mach=avai_mach;
                    job_set(i).avai_worker_num=avai_worker_num;
                    job_set(i).avai_worker=avai_worker;
                    for j=1:job_set(i).stage
                        for w=1:avai_worker_num(j)
                            for m=1:job_set(i).avai_mach_num(j)
                                if j==1
                                    job_set(i).pro_time{1,w}(j,m)= randi([10,60]);
                                    job_set(i).low_carbon{1,w}(j,m)= randi([200,250])/job_set(i).pro_time{1,w}(j,m);
                                else
                                    job_set(i).pro_time{1,w+sum(avai_worker_num(1:j-1))}(j,m)= randi([10,60]);
                                    job_set(i).low_carbon{1,w+sum(avai_worker_num(1:j-1))}(j,m)= randi([200,250])/job_set(i).pro_time{1,w+sum(avai_worker_num(1:j-1))}(j,m);
                                end
                            end
                        end
                    end
                    distribute_centre_location=[round(rand(1)*500);round(rand(1)*500)];
                    manuf_location=[round(rand(1)*500);round(rand(1)*500)];
                    m_j_dis(i)=pdist([manuf_location';job_set(i).location'],'euclidean');
                    %% duetime
                    pro_time_sum=0;
                    for j=1:stage_num
                        for w=1:avai_worker_num(j)
                            pro_time_sum=sum(sum(job_set(i).pro_time{1,w+sum(avai_worker_num(1:j-1))}))+pro_time_sum;
                        end
                    end
                    c=1+0.06*rand*job_num;
                    due_multi_p(i,1)=round(c*(pro_time_sum/max(avai_mach_num)/sum(avai_worker_num)*stage_num)+m_j_dis(i)/sum([tran_set.speed])/3);
                    job_set(i).due_multi_p(1,1)=due_multi_p(i);
                end
                ma_num=sum(job_set(1).avai_mach_num);
                for m=1:ma_num
                    idle_carbon(m)=10+randperm(20,1);
                    on_carbon(m)=10+randperm(10,1);
                end
                %% ��ά����Ч��
                n_p=4;
                hv=[];
                for i=1:job_num
                    V_p(i,1)=randi([21,25],1,1);
                    V_p(i,2)=randi([16,20],1,1);
                    V_p(i,3)=randi([11,15],1,1);
                    V_p(i,4)=randi([6,10],1,1);    
                    job_set(i).V_p(1,1)=V_p(i,1);
                    job_set(i).V_p(1,2)=V_p(i,2);
                    job_set(i).V_p(1,3)=V_p(i,3);
                    job_set(i).V_p(1,4)=V_p(i,4);
                end
                a=randi([-156,-45],1,job_num)/100;
                b=(25-4.*a)./2;
                for j2=1:job_num
                    for j=1:4
                        p=[a(j2) b(j2) -V_p(j2,j)];
                        de=roots(p);
                        V_de(j2,j)=min(de);
                    end
                end
                V_dee=V_de.*100;
                V_de(:,1)=ceil(V_dee(:,1))/100;%����ȡ��
                for i=1:job_num
                    for j=2:4
                        if V_p(i,j)/(ceil(V_dee(i,j))/100)>(V_p(i,j-1)/V_de(i,j-1))
                            V_de(i,j)=ceil(V_dee(i,j))/100;%����ȡ��
                        else
                            V_de(i,j)=fix(V_dee(i,j))/100;%����ȡ��
                        end
                    end
                end
                hv(:,1)=due_multi_p(:,1).*V_de(:,1);%����ֵ
                due_multi_p(:,2)=hv(:,1)./V_de(:,2);
                due_multi_p(:,3)=hv(:,1)./V_de(:,3);
                due_multi_p(:,4)=hv(:,1)./V_de(:,4);
                due_multi_p=round(due_multi_p);
                for j=1:job_num
                    job_set(j).due_multi_p(1,2)=due_multi_p(j,2);
                    job_set(j).due_multi_p(1,3)=due_multi_p(j,3);
                    job_set(j).due_multi_p(1,4)=due_multi_p(j,4);
                    job_set(j).V_de(1,:)=V_de(j,:);
                    job_set(j).V_de(1,:)=V_de(j,:);
                    job_set(j).V_de(1,:)=V_de(j,:);
                    job_set(j).V_de(1,:)=V_de(j,:);
                    job_set(j).hv=hv(j,1);
                end
                w=w+1;
                save_name = strcat(num2str(job_num),'x',num2str(stage_num),'_',num2str(group));
                save (save_name,'job_set','due_multi_p','V_de','V_p','n_p','distribute_centre_location','manuf_location','idle_carbon','manuf_location','avai_mach_num','avai_worker_num','tran_set','on_carbon');
                clear job_set;
                clear due_multi_p;
                clear V_de;
                clear V_p;
                clear V_d;
                clear hv;
            end
    end
end
